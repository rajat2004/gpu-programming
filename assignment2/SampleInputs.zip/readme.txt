# ReadMe
- These are just sample inputs.
- So, we recommend you to test the program on other inputs within given limits.
- Evaluation includes larger instances.
- Note: Inputs are shown as 2D Matrix (for easy visualization). 
- So, any loop(s) that executes scanf("%d"..)  m*n times should work!

## Limits
  * -100 <= A(i,j) <= 100
  * 2^1 <= m <= n <= 2^13
  * k = {1, 2, 4, 8, 16, 32}
